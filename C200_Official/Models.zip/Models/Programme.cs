﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


#nullable disable

namespace C200_Official.Models
{
    public partial class Programme
    {
        public int Id { get; set; }
    [Required(ErrorMessage ="Please enter title")]
        public string Title { get; set; }
        public string PicFile { get; set; }
        public string Status { get; set; }
        [Required(ErrorMessage = "Please enter description")]
        public string Description { get; set; }
        
        public string Link { get; set; }
        [Required]
        public int CategoryId { get; set; }

        public virtual Category Category { get; set; }
    }
}
